import Input from "./input";

const Components = { Input };

export default Components;
