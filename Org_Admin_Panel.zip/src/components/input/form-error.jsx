const FormError = ({ error }) => (
  <div className="flex text-xs font-semibold mt-1 text-red-500">{error}</div>
);
export default FormError;