const establishedYear = [
  {
    id: 0,
    value: "2023",
    label: "2023",
  },
  { id: 1, value: "2024", label: "2024" },
];

const states = [
  {
    id: "ce2e86063c314d5283b259df6a573652",
    value: "Punjab",
    label: "Punjab",
  },
];

const district = [
  {
    id: "ce523c1c29104a88baf637d34608c92d",
    value: "Mohali",
    label: "Mohali",
    // id: "ce523c1c29104a88baf637d34608c92d",
    // areas: [
    //   {
    //     id: "accb07e5f4c945939e2888dc76fdf5fb",
    //     value: "Kharar",
    //     label: "Kharar",
    //   },
    // ],
    // title: "Mohali",
  },
];

const locality = [
  {
    id: "accb07e5f4c945939e2888dc76fdf5fb",
    value: "Kharar",
    label: "Kharar",
    // id: "ce523c1c29104a88baf637d34608c92d",
    // areas: [
    //   {
    //     id: "accb07e5f4c945939e2888dc76fdf5fb",
    //     value: "Kharar",
    //     label: "Kharar",
    //   },
    // ],
    // title: "Mohali",
  },
];
export { establishedYear, states, district,locality };
