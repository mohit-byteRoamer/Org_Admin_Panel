import employeeAvatar from "../assets/image/employee-avatar.png";

export const icons = {};

export const image = {
  employeeAvatar,
};
